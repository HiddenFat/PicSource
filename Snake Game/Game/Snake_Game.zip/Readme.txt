Gangjun Ha
Snake Game

Use arrow keys to move 
Get white blocks to increase your size
Avoid red blocks as it will decrease your size

click on screen to change your snake color

You can simply change the speed of the game or number of grids
by changing the number in the sourcecode.